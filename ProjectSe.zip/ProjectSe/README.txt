- Step 1
extract ProjectSe.zip

- Step 2
pindahin Folder ProjectSe ke dalam directory xampp\htdocs

- Step 3 
jalankan xampp -> start apache, mysql, filezilla

- Step 4 
buka phpmyadmin -> pilih menu import -> import file learning_app.sql (ada dalam folder ProjectSe\database) pastikan database
sudah terimport

- Step 5
http://localhost/ProjectSe/index.php buka link tsb di browser

- Step 6
gunakan username : yuza.yushita ; password : 1212 untuk login sebagai pengajar sehingga bisa mengakses dashboard untuk
mengelola konten pembelajaran

NOTE:
untuk saat ini, jika ingin menambah materi, anda dapat mempaste link url video youtube atau dari manapun, dan jika link file pdf
or ppt pastikan agar file tsb sudah di upload ke gdrive dan salin link lalu pastekan link tersebut pada menu tambah materi

untuk tambah tugas dan quiz, saat ini hanya bisa di tambah aja, blm bisa untuk di buka seperti materi dan untuk nilai masih dalam
pengembangan