<?php
// Konfigurasi koneksi database
$host = 'localhost';
$db = 'learning_app';
$user = 'root';
$pass = '';

// Membuat koneksi ke database
$conn = new mysqli($host, $user, $pass, $db);

// Periksa koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
