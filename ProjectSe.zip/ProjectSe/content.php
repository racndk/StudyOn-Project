<?php
include("welcome.php");
include("koneksi.php");

// Mengecek apakah parameter pertemuan ada dalam URL
if (isset($_GET['pertemuan'])) {
    // Mengambil nilai pertemuan dari URL
    $pertemuan = $_GET['pertemuan'];

    // Kode PHP untuk mengambil data dari database berdasarkan pertemuan
    $query = "SELECT link_materi FROM course WHERE pertemuan = '$pertemuan'";
    $result = mysqli_query($conn, $query);

    // Memeriksa apakah query berhasil dijalankan dan mendapatkan satu baris data
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $linkMateri = $row['link_materi'];
    }
} else {
    // Jika parameter pertemuan tidak ada dalam URL, kita dapat mengatur nilai default atau melakukan tindakan lain
    $linkMateri = "default_link_materi.html";
    echo "Parameter pertemuan tidak ditemukan.";
}
?>
<style>
    .ion-icon-white{
    width: 40px;
    height: 40px;
    background-color: #fff;
    color: rgb(29, 28, 61);
    border-radius: 50px;
    padding: 2px;
    transition: 0.5s;
}
.ion-icon-white:hover{
    transition: 0.5s;
    background-color: rgb(29, 28, 61);
    color: #fff;
}
</style>
<link rel="stylesheet" href="CSS/drama.css">
<section id="top">
    <div class="slide-container">
        <div class="slide">
            <iframe src="<?php echo $linkMateri; ?>" frameborder="0" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
        </div>
        <div class="navigasi">
            <a href="#hal1"><ion-icon name="chevron-down-outline" class="ion-icon-white"></ion-icon></a>
        </div>
    </div>
</section>

<section id="hal1">
    <div class="container-game">
        <div class="navigasi">
            <a href="#top"><ion-icon name="chevron-up-outline"></ion-icon></a>
        </div>
        <div class="game-content">
            <iframe src="game.html" frameborder="0"></iframe>
        </div>
    </div>
</section>

<!-- ====== ionicons ======= -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

<?php
include("footer.php");
?>
