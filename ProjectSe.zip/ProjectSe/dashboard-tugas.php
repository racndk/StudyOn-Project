<?php
include("dashboard-app.php");
include("koneksi.php");
// Memeriksa apakah ada permintaan penghapusan materi
if (isset($_POST['hapus_pertemuan'])) {
        $pertemuan = $_POST['pertemuan'];
    
        // Kode SQL untuk menghapus materi berdasarkan nomor pertemuan
        $query_hapus = "DELETE FROM tugas WHERE pertemuan = '$pertemuan'";
        if (mysqli_query($conn, $query_hapus)) {
            // Redirect ke halaman sukses atau halaman lain yang diinginkan
            echo '<p style="position:absolute; top:50%; left:40%;">Berhasil menghapus materi. Silahkan cek menu materi</p>';
            exit();
        } else {
            echo '<p style="position:absolute; top:50%; left:40%;">Terjadi kesalahan dalam menghapus tugas. Silakan coba lagi.</p>';
        }
    }
?>
<style>
    body{
        background-color: rgb(230, 230, 230);
    }
        .main-title{
        display: flex;
        justify-content: space-between;
        margin:10px 0px;
    }
    .container-materi{
    margin-left: 300px;
    margin-right: 50px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    grid-gap: 1rem;
}
.materi{
    background-color: rgba(29, 28, 61, 0.783);
    border-radius: 15px;
}
.materi > a{
    color: #fff;
    text-decoration: none;
    display: grid;
    justify-content: center;
    text-align: center;
    padding: 20px;
}
</style>
<link rel="stylesheet" href="CSS/dashboard-materi.css">
<div class="main-title">
        <div class="add-new-user" style="margin:10px 0; ">
                <a href="tambah-tugas.php">Tambah Tugas</a>
        </div>
        <div class="delete-materi" style="margin:10px 52px 10px 0; ">
                <form action="" method="post">
                <input type="number" name="pertemuan" placeholder="Nomor Pertemuan" required>
                <button type="submit" name="hapus_pertemuan">Hapus Tugas</button>
                </form>
        </div>
</div>

<div class="container-materi">
    <?php
    // Kode PHP untuk mengambil data dari database
    $query = "SELECT pertemuan,materi,file_tugas FROM tugas";
    $result = mysqli_query($conn, $query);

    // Memeriksa apakah query berhasil dijalankan dan mendapatkan setidaknya satu baris data
    if ($result && mysqli_num_rows($result) > 0) {
        // Menampilkan tag div dengan class materi sebanyak jumlah data pada kolom pertemuan
        while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <div class="materi">
            <a href="#">
                <img src="Asset/tugas.png" alt="" width="100px"height="100px">
                <div class="title">
                    <h5>Tugas Pertemuan <?php echo $row['pertemuan']; ?></h5>
                </div>
                <div class="title">
                    <p><?php echo $row['materi']; ?></p>
                </div>
            </a>
        </div>
    <?php
        }
    }
    ?>
</div>

<?php
include("footer.php");
?>