<?php
include("koneksi.php");

// Memeriksa apakah parameter ID ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Menghapus data dari tabel user berdasarkan ID
    $query = "DELETE FROM user WHERE id_siswa = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);

    // Memeriksa apakah data berhasil dihapus
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        // Jika berhasil, redirect ke halaman data_user.php atau halaman lainnya
        header("Location: data-siswa.php");
        exit();
    } else {
        // Jika tidak ada data yang dihapus, tampilkan pesan error
        echo "Error: Data not found.";
    }
} else {
    // Jika parameter ID tidak ada dalam URL, tampilkan pesan error
    echo "Error: Invalid ID.";
}
?>
