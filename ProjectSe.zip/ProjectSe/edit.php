<?php
ob_start(); // Start output buffering

include("dashboard-app.php");
include("koneksi.php");

if (isset($_POST['submit'])) {
    // Ambil nilai dari form
    $idSiswa = isset($_POST['id_siswa']) ? $_POST['id_siswa'] : '';
    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';
    $kelas = isset($_POST['kelas']) ? $_POST['kelas'] : ''; 
    $usia = isset($_POST['usia']) ? $_POST['usia'] : '';
    $noTelepon = isset($_POST['no_telp']) ? $_POST['no_telp'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
    $jenisKelamin = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : '';

    // Perbarui data pengguna di database
    $query = "UPDATE user SET nama='$nama', role='$role', kelas='$kelas', usia='$usia', no_telp='$noTelepon',
              username='$username', password='$password', alamat='$alamat', jenis_kelamin='$jenisKelamin'
              WHERE id_siswa='$idSiswa'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Jika perbarui berhasil, redirect ke halaman data_user.php atau halaman lainnya
        header("Location: data_user.php");
        exit();
    } else {
        // Jika perbarui gagal, tampilkan pesan error
        echo "Error: " . mysqli_error($conn);
    }
}

// Ambil data pengguna berdasarkan ID
if (isset($_GET['id'])) {
    $idSiswa = $_GET['id'];
    $query = "SELECT * FROM user WHERE id_siswa='$idSiswa'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if (!$data) {
        // Jika data pengguna tidak ditemukan, redirect ke halaman data_user.php atau halaman lainnya
        header("Location: data_user.php");
        exit();
    }

    // Mengambil nilai kolom 'profile' dari data pengguna
    $profilePath = $data['profile'];
} else {
    // Jika ID tidak ada, redirect ke halaman data_user.php atau halaman lainnya
    header("Location: data_user.php");
    exit();
}
ob_end_flush(); // Flush the output buffer
?>

<link rel="stylesheet" href="CSS/tambah-user.css">
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<div class="title">
    <h2>Edit Pengguna</h2>
</div>
<div class="container-add-user">
    <div class="form-add-user">
        <div class="input">
            <div class="input-profile">
                <?php
                if (isset($profilePath)) {
                    echo '<img style="border-radius:50%;" width="50px" height="50px" src="data:image/jpeg;base64,' . base64_encode($profilePath) . '" alt="Profile">';
                } else {
                    echo '<img src="Asset/default-profile.png" alt="">';
                }
                ?>
                <div class="btn-ganti-foto">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="MAX_FILE_SIZE" value="2000000">
                        <input type="file" name="foto" id="foto" style="display: none;">
                        <label for="foto">Ganti Foto</label>
                    </form>
                </div>
            </div>
            <div class="input-data">
                <form method="POST" enctype="multipart/form-data">
                    <div class="input-data">
                        <input type="text" name="id_siswa" value="<?php echo $data['id_siswa']; ?>">
                        <input type="text" name="nama" placeholder="Nama" value="<?php echo $data['nama']; ?>">
                    </div>
                    <div class="input-data">
                        <input type="text" name="role" placeholder="Role" value="<?php echo $data['role']; ?>">
                        <input type="text" name="kelas" placeholder="Kelas" value="<?php echo $data['kelas']; ?>">
                    </div>
                    <div class="input-data">
                        <input type="text" name="usia" placeholder="Usia" value="<?php echo $data['usia']; ?>">
                        <input type="text" name="no_telp" placeholder="No Telepon" value="<?php echo $data['no_telp']; ?>">
                    </div>
                    <div class="input-data">
                    <input type="text" name="username" placeholder="Username" value="<?php echo $data['username']; ?>">
                    <input type="text" name="password" placeholder="Password" value="<?php echo $data['password']; ?>">
                    </div>
                    <div class="input-alamat">  
                        <textarea name="alamat" cols="42" rows="5" placeholder="Alamat"><?php echo $data['alamat']; ?></textarea>
                    </div>
                    <div class="gender">
                        <label>Jenis Kelamin:</label>
                        &nbsp;
                        <input type="radio" class="form-check-input" name="jenis_kelamin" id="male"
                            value="Laki Laki" <?php if ($data['jenis_kelamin'] === 'Laki Laki') echo 'checked'; ?>>
                        <label for="male" class="form-input-label">Laki Laki</label>
                        &nbsp;
                        <input type="radio" class="form-check-input" name="jenis_kelamin" id="female"
                            value="Perempuan" <?php if ($data['jenis_kelamin'] === 'Perempuan') echo 'checked'; ?>>
                        <label for="female" class="form-input-label">Perempuan</label>
                    </div>
                    <div class="btn-sub-cancel">
                        <button type="submit" class="btn btn-success" name="submit">Save</button>
                        <a href="javascript:history.back()" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<?php
include("footer.php");
?>
