<?php
include("dashboard-app.php");
include("koneksi.php");
if (isset($_POST['submit'])) {

    // Memeriksa apakah file foto berhasil diupload
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        // Mengambil informasi file foto yang diupload
        $fotoName = $_FILES['foto']['name'];
        $fotoTmp = $_FILES['foto']['tmp_name'];
        $fotoPath = "uploads/" . $fotoName;

        // Memindahkan file foto yang diupload ke folder "uploads"
        move_uploaded_file($fotoTmp, $fotoPath);
    } else {
        // Jika tidak ada file foto yang diupload, ambil foto profil default
        $fotoPath = "Asset/default-profile.png";
    }

    // Ambil nilai dari form
    $idSiswa = isset($_POST['id_siswa']) ? $_POST['id_siswa'] : '';
    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';
    $kelas = isset($_POST['kelas']) ? $_POST['kelas'] : '';
    $usia = isset($_POST['usia']) ? $_POST['usia'] : '';
    $noTelepon = isset($_POST['no_telp']) ? $_POST['no_telp'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
    $jenisKelamin = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : '';

    // Memasukkan data ke dalam tabel user
    $query = "INSERT INTO user (id_siswa, nama, role, kelas, usia, no_telepon, username, password, alamat, profile)
              VALUES ('$idSiswa', '$nama', '$role', '$kelas', '$usia', '$noTelepon', '$username', '$password', '$alamat', '$fotoPath')";
    mysqli_query($conn, $query);

    if ($result) {
        // Jika insert berhasil, redirect ke halaman index.php atau halaman lainnya
        header("Location: data_user.php");
        exit();
    } else {
        // Jika insert gagal, tampilkan pesan error
        echo "Error: " . mysqli_error($conn);
    }
}

?>