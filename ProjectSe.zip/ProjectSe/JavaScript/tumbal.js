const questions = [
  {
    question: "Apa bahasa pemrograman yang sering digunakan untuk membuat interaksi pada website?",
    answer: "javascript"
  },{
    question: "2?",
    answer: "html"
  }
  // Tambahkan pertanyaan dan jawaban lain jika diperlukan
];

const words = [
  "javascript",
  "html",
  "css",
  "game",
  "code",
  "website",
  "computer",
  "program",
  "developer",
  "internet",
  "technology",
  "design",
  "database",
  "mobile",
  "framework",
  "syntax",
  "responsive",
  "debug",
  "frontend",
  "backend"
];
const questionContainer = document.getElementById('question-container');
const btnStart = document.getElementById('btn-start');
const questionText = document.getElementById('question');
const timeLeftText = document.getElementById('time-left');
const startButton = document.getElementById('start-button');
const wordGrid = document.getElementById('word-grid');
const message = document.getElementById('message');
const resultContainer = document.getElementById('result-container');
const timeTakenText = document.getElementById('time-taken');
const scoreText = document.getElementById('score');
const wrongText = document.getElementById('wrong');
const retryButton = document.getElementById('retry-button');

let timeTaken = 0;
let score = 0;
let currentQuestionIndex = 0;
let answerFound = false;
let timer;
let wrong= 0;

startButton.addEventListener('click', startGame);

function startTimer() {
  timer = setInterval(() => {
    timeTaken++;
    showTimeLeft();
    if (timeTaken >= 20000) {
      clearInterval(timer);
      showMessage('Waktu telah habis');
      setTimeout(showResult, 2000);
    }
  }, 1000);
}

function startGame() {
  questionContainer.style.display = 'block';
  startButton.style.display = 'none';
  btnStart.style.display = 'none';
  showQuestion();
  showTimeLeft();
  shuffleArray(words);
  createWordGrid();
  startTimer();
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
function showQuestion() {
  questionText.textContent = questions[currentQuestionIndex].question;
  shuffleArray(words);
  createWordGrid();
}

function showTimeLeft() {
  const timeLeft = 20000 - timeTaken;
  timeLeftText.textContent = `Sisa Waktu: ${timeLeft} detik`;
}

function createWordGrid() {
  wordGrid.innerHTML = '';
  words.forEach((word) => {
    const wordElement = document.createElement('div');
    wordElement.classList.add('word');
    wordElement.textContent = word;
    wordElement.addEventListener('click', checkAnswer);
    wordGrid.appendChild(wordElement);
  });
}

function checkAnswer(event) {
  if (answerFound) return;

  const selectedWord = event.target.textContent;
  const answer = questions[currentQuestionIndex].answer;

  if (selectedWord === answer) {
    answerFound = true;
    event.target.classList.add('found');
    showMessage('Jawaban ditemukan!');
    score++;
    setTimeout(() => {
      currentQuestionIndex++;
      if (currentQuestionIndex >= questions.length) {
        showResult();
      } else {
        answerFound = false;
        showQuestion();
        createWordGrid();
        timeTaken = 0;
        showTimeLeft();
      }
    }, 1500);
  } else if (selectedWord != answer) {
    wrong++;
    showMessage('Bukan kata yang tepat');
  }
}

function retryGame() {
  currentQuestionIndex = 0;
  score = 0;
  timeTaken = 0;
  answerFound = false;
  showQuestion();
  createWordGrid();
  showTimeLeft();
  resultContainer.style.display = 'none';
  questionContainer.style.display = 'block';
  wordGrid.style.display = 'grid';
  message.style.display = 'block';
  startTimer();
}


function showResult() {
  clearInterval(timer);
  questionContainer.style.display = 'none';
  wordGrid.style.display = 'none';
  message.style.display = 'none';
  resultContainer.style.display = 'block';
  timeTakenText.textContent = `Waktu Pencarian Jawaban: ${timeTaken} detik`;
  scoreText.textContent = `Skor: ${score}`;
  wrongText.textContent = `Wrong Click: ${wrong}`;
}
function showMessage(text) {
  message.textContent = text;
  message.style.display = 'block';

  setTimeout(() => {
    message.style.display = 'none';
  }, 1500);
}
retryButton.addEventListener('click',retryGame);