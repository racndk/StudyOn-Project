const words = [
    {
        word: "monolog",
        hint: "Salah satu jenis drama"
    },
    {
        word: "absurd",
        hint: "Bentuk lain dari drama adalah drama..."
    },
    {
        word: "borjuis",
        hint: "Bentuk lain dari drama adalah drama..."
    },
    {
        word: "duka",
        hint: "Bentuk lain dari drama adalah drama..."
    }
    // Tambahkan kata-kata lainnya di sini
];

let score = 0;
let currentWordIndex = 0;
let currentWord = words[currentWordIndex];
let timeRemaining = 25;
let timerInterval;
let correctAnswers = 0;
let wrongAnswers = 0;

const startButton = document.getElementById("start-button");
const gameContainer = document.getElementById("game-container");
const wordText = document.getElementById("word-text");
const inputField = document.getElementById("input-field");
const nextButton = document.getElementById("next-button");
const hintText = document.getElementById("hint-text");
const scoreElement = document.getElementById("score");
const timerValue = document.getElementById("timer-value");
const resultContainer = document.getElementById("result-container");
const finalScoreElement = document.getElementById("final-score");
const correctAnswersElement = document.getElementById("correct-answers");
const wrongAnswersElement = document.getElementById("wrong-answers");
const retryButton = document.getElementById("retry-button");
const exitButton = document.getElementById("exit-button");

// POP UP MUST BE FILLED
const popUpMustBeFilled = document.getElementById("pop-up-harus-isi");
const popUp = document.getElementById("pop-up-content");
const closeButton =  document.getElementById("close-button");

// FUNCTION POP UP MUST BE FILLED
function showPopUpMustFilled(){
    popUpMustBeFilled.style.display = "block";
    popUp.classList.add("zoomIn");
    clearInterval(timerInterval);
}
function closePopUp(){
    popUpMustBeFilled.style.display = "none";
    popUp.classList.remove("zoomIn");
    initGame();
}

// POP UP WRONG ANSWER
const wrongPopUp = document.getElementById("pop-up-wrong-answers");
const wrongPopUpContent = document.getElementById("wrong-answers-pop-up-content");
const tryAgainButton =  document.getElementById("tryAgain-button");
const skipButton =  document.getElementById("skip-button");

// FUNCTION POP UP WRONG ANSWER
function showWrongAnswerPopUp(){
    wrongPopUp.style.display = "block";
    wrongPopUpContent.classList.add("zoomIn");
    clearInterval(timerInterval);
}
function closeWrongPopUp(){
    wrongPopUp.style.display = "none";
    wrongPopUpContent.classList.remove("zoomIn");
    initGame();
}
function skipQuestion(){
    currentWordIndex++;
    currentWord = words[currentWordIndex];
    wrongAnswers++;
    closeWrongPopUp();
    initGame();
}
function skipQuestionTimeIsUp(){
    currentWordIndex++;
    currentWord = words[currentWordIndex];
    wrongAnswers++;
    closeTimeIsUpPopUp();
    initGame();
}

// POP UP CORRECT
const correctPopUp = document.getElementById("correct-pop-up");
const correctContent = document.getElementById("correct-pop-up-content");
const correctNext = document.getElementById("correct-next-button");

// FUNCTION POP UP CORRECT
function showCorrectPopUp(){
    correctPopUp.style.display = "block";
    correctContent.classList.add("zoomIn");
    clearInterval(timerInterval);
}
function closeCorrectPopUp(){
    correctPopUp.style.display = "none";
    correctContent.classList.remove("zoomIn");
    initGame();
}

// POP UP TIME'S UP
const TimeIsUpPopUp = document.getElementById("pop-up-times-up");
const TimeIsUpPopUpContent = document.getElementById("times-up-pop-up-content");
const tryAgainButtonTimeIsUp =  document.getElementById("tryAgain-button-timesup");
const skipButtonTimeIsUp =  document.getElementById("skip-button-timesup");

// FUNCTION POP UP TIME'S UP 
function showTimeIsUpPopUp(){
    TimeIsUpPopUp.style.display = "block";
    TimeIsUpPopUpContent.classList.add("zoomIn");
    clearInterval(timerInterval);
}
function closeTimeIsUpPopUp(){
    TimeIsUpPopUp.style.display = "none";
    TimeIsUpPopUpContent.classList.remove("zoomIn");
    initGame();
}


startButton.addEventListener("click", startGame);

function startGame() {
    score = 0;
    currentWordIndex = 0;
    currentWord = words[currentWordIndex];
    timeRemaining = 25;
    correctAnswers = 0;
    wrongAnswers = 0;
    timeTaken = 0;
    resultContainer.style.display = "none";
    gameContainer.style.display = "block";
    startButton.parentNode.style.display = "none";
    initGame();
}


function initGame() {
    if (currentWordIndex >= words.length) {
        // Semua kata telah digunakan. Selesaikan game
        showResult();
        clearInterval(timerInterval);
        return;
    }

    let capital = currentWord.word.toUpperCase();
    let wordArray = capital.split("");
    wordArray.sort(() => Math.random() - 0.5);
    wordText.textContent = wordArray.join(" ");
    hintText.textContent = currentWord.hint;
    inputField.value = "";
    inputField.focus();
    scoreElement.textContent = score;
    timeRemaining = 25;
    timerValue.textContent = timeRemaining;

    clearInterval(timerInterval);
    timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    timeRemaining--;
    timerValue.textContent = timeRemaining;

    if (timeRemaining === 0) {
        clearInterval(timerInterval);
        showTimeIsUpPopUp();
        currentWord = words[currentWordIndex];
        return;
    }
}

function checkAnswer() {
    let jawaban = currentWord.word.toUpperCase();
    let userInput = inputField.value.toUpperCase();
    if(!userInput){
        showPopUpMustFilled();
        currentWord = words[currentWordIndex];
        return;
    }
    if (userInput === jawaban) {
        score+= 25;
        currentWordIndex++;
        correctAnswers++;
        showCorrectPopUp();
        currentWord = words[currentWordIndex];
        return;
    } else if(userInput != jawaban) {
        showWrongAnswerPopUp();
        currentWord = words[currentWordIndex];
        return;
    }
}
function showResult() {
    gameContainer.style.display = "none";
    resultContainer.style.display = "block";
    resultContainer.classList.add("zoomIn");
    finalScoreElement.textContent = score;
    correctAnswersElement.textContent = correctAnswers;
    wrongAnswersElement.textContent = wrongAnswers;
}

function retryGame() {
    score = 0;
    currentWordIndex = 0;
    currentWord = words[currentWordIndex];
    timeRemaining = 25;
    correctAnswers = 0;
    wrongAnswers = 0;
    resultContainer.style.display = "none";
    gameContainer.style.display = "block";
    initGame();
}
function exitGame() {
    alert("Terima kasih telah bermain!");
    // Tambahkan kode untuk mengarahkan ke halaman lain atau melakukan tindakan setelah keluar dari game
    startButton.parentNode.style.display = "block";
    resultContainer.style.display = "none";
}

correctNext.addEventListener("click",closeCorrectPopUp)
tryAgainButton.addEventListener("click",closeWrongPopUp);
tryAgainButtonTimeIsUp.addEventListener("click",closeTimeIsUpPopUp);
skipButton.addEventListener("click",skipQuestion);
skipButtonTimeIsUp.addEventListener("click",skipQuestionTimeIsUp);
closeButton.addEventListener("click",closePopUp);
nextButton.addEventListener("click", checkAnswer);
retryButton.addEventListener("click", retryGame);
exitButton.addEventListener("click", exitGame);

