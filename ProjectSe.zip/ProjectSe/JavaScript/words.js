const words = [
    {
        word: "monolog",
        hint: "salah satu jenis drama"
    },
    {
        word: "absurd",
        hint: "bentuk lain dari drama adalah drama..."
    },
    {
        word: "borjuis",
        hint: "bentuk lain dari drama adalah drama..."
    },
    {
        word: "domestik",
        hint: "bentuk lain dari drama adalah drama..."
    },
    {
        word: "duka",
        hint: "bentuk lain dari drama adalah drama..."
    },
    {
        word: "rakyat",
        hint: "bentuk lain dari drama adalah drama..."
    },
    {
        word: "liturgis",
        hint: "bentuk lain dari drama adalah drama..."
    },
]