// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "STRUKTUR DRAMA YANG ADA PADA TEKS BERIKUT TERMASUK PADA BAGIAN?",
    img_que: "Rani dan Nasa sedang berduduk santai di teras depan rumah saat matahari sore menjelang terbenam. Mereka sebenarnya sedang menunggu seorang yang sudah lama tidak pernah pulang ke rumah. Situasi diam yang ada di antara mereka membuat Rani merasa kurang nyaman dan akhirnya berusaha untuk memberanikan diri berbicara.",
    answer: "Prolog",
    options: [
      "Babak",
      "Adegan",
      "Epilog",
      "Prolog",
      "Diaolog"
    ]
  },
    {
      numb: 2,
      question: "STRUKTUR DRAMA YANG ADA PADA TEKS BERIKUT TERMASUK PADA BAGIAN?",
      img_que: "Melihat saudara kembarnya yang mulai kehilangan kesabaran, Nasa menghembuskan nafasnya yang berat. Dia tahu dan sadar mereka sudah menunggu terlalu lama. Akan tetapi, dia yakin dan tetap ada di teras menunggu Ayahnya yang janji akan segera pulang.",
      answer: "Epilog",
      options: [
        "Babak",
        "Adegan",
        "Epilog",
        "Prolog",
        "Diaolog"
      ]
  }
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];