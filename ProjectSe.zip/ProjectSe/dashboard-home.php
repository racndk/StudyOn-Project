<?php
include("dashboard-app.php");
include("koneksi.php");

$data_siswa = mysqli_query($conn, "select * from user where role = 'Murid'");
if($data_siswa != NULL){
    $jumlah_siswa = mysqli_num_rows($data_siswa);
}else{
    $jumlah_siswa = 0;
}

$data_materi = mysqli_query($conn, "select * from course");
if($data_materi != NULL){
    $jumlah_materi = mysqli_num_rows($data_materi);
}else{
    $jumlah_materi = 0;
}

$data_tugas = mysqli_query($conn, "select * from tugas");
if($data_tugas != NULL){
    $jumlah_tugas = mysqli_num_rows($data_tugas);
}else{
    $jumlah_tugas = 0;
}

$data_quiz = mysqli_query($conn, "select * from quiz");
if($data_quiz != NULL){
    $jumlah_quiz = mysqli_num_rows($data_quiz);
}else{
    $jumlah_quiz = 0;
}

?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="CSS/dashboard-home.css">
<style>
    body{
        background-color: rgb(230, 230, 230);
    }
.box-container{
    margin:10px 0px 10px 300px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    grid-gap: 5px;
}
    .box{
    width: 200px;
    height: 100px;
    padding:10px 20px;
    margin-bottom:10px;
    background-color: #fff;
    border-left:5px solid rgba(29, 28, 61);
    border-radius:5px;
    display:grid;
    text-align:center;
}
.title{
    display:flex;
    justify-content:center;
    align-items:center;
    margin-bottom:10px;
}
a{
    text-decoration:none;
    color:rgba(29, 28, 61);
}


.daftar-user{
    width: auto;
    margin-top:25px;
    margin-left:250px;
    padding: 0px 20px 0px 50px;
    }
    tr > td > img{
        width: 80px;
        height: 80px;
    }
    tr > td > a{
        text-decoration: none;
        color: #fff;
    }
    tr > td, tr > th{
        padding: 5px 15px;
        text-align: justify;
        align-items: center;
    }
    table {
    border-collapse: collapse;
    }
    th, td {
    border: 2px solid black;
    }
    th{
        color:#fff;
        background-color: rgba(29, 28, 61); 
    }
    .cursor{
        cursor:pointer;
    }
    .link-dark{color:rgba(29, 28, 61)!important;transition:.5s;}
    .link-dark:focus,
    .link-dark:hover{color:rgba(29, 28, 61, 0.455)!important;transition:.5s;}

    
    .daftar-user > .add-new-user > a{
    color:#fff; 
    text-decoration:none;
    background-color: rgba(29, 28, 61); 
    padding:5px 10px;
    border-radius:5px;
    transition:.5s;
    font-size:25px;
    cursor: none;
    }
    
@media (min-width:890px) {
    .box-container { grid-template-columns: repeat(2, 1fr); }
  }
  @media (min-width: 1065px) {
    .box-container { grid-template-columns: repeat(3, 1fr); }
  }
  
</style>
<div class="box-container">
<a href="data-siswa.php">
<div class="box">  
    <div class="title">
        <p>Jumlah Siswa</p>
    </div>
    <div class="subcontent">
        <div class="">
            <ion-icon name="accessibility-outline" style="font-size: 40px;"></ion-icon>
        </div>
        <div class="">
            <p><?php echo $jumlah_siswa?> Siswa</p>
        </div>
    </div>
</div>
</a>
<a href="dashboard-materi.php">
<div class="box">  
    <div class="title">
        <p>Jumlah Pertemuan</p>
    </div>
    <div class="subcontent">
        <div class="">
            <ion-icon name="newspaper-outline" style="font-size: 40px;"></ion-icon>
        </div>
        <div class="">
            <p><?php echo $jumlah_materi?> Pertemuan</p>
        </div>
    </div>
</div>
</a>
<a href="dashboard-tugas.php">
<div class="box">  
    <div class="title">
        <p>Jumlah Tugas</p>
    </div>
    <div class="subcontent">
        <div class="">
            <ion-icon name="reader-outline" style="font-size: 40px;"></ion-icon>
        </div>
        <div class="">
            <p><?php echo $jumlah_tugas?> Tugas</p>
        </div>
    </div>
</div>
</a>
<a href="dashboard-quizz.php">
<div class="box">  
    <div class="title">
        <p>Jumlah Quiz</p>
    </div>
    <div class="subcontent">
        <div class="">
            <ion-icon name="game-controller-outline" style="font-size: 40px;"></ion-icon>
        </div>
        <div class="">
            <p><?php echo $jumlah_quiz?> Quiz</p>
        </div>
    </div>
</div>
</a>
</div>

<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<?php
include("footer.php");
?>