<?php
include("welcome.php");
include("koneksi.php");
?>
<link rel="stylesheet" href="CSS/landing-page.css">
<section class="wrapper-content">
    <?php
    // Kode PHP untuk mengambil data dari database
    $query = "SELECT pertemuan, materi FROM course";
    $result = mysqli_query($conn, $query);

    // Memeriksa apakah query berhasil dijalankan dan mendapatkan setidaknya satu baris data
    if ($result && mysqli_num_rows($result) > 0) {
        // Menampilkan tag div dengan class materi sebanyak jumlah data pada kolom pertemuan
        while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <div class="chapter">
            <a href="content.php?pertemuan=<?php echo $row['pertemuan']; ?>">
                <img src="Asset/book.png" alt="">
                <div class="title">
                    <h5>Pertemuan <?php echo $row['pertemuan']; ?></h5>
                </div>
                <div class="title">
                    <p><?php echo $row['materi']; ?></p>
                </div>
            </a>
        </div>
    <?php
        }
    }
    ?>
</section>