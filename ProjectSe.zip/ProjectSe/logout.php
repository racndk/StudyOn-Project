<?php
// Menghapus semua data session
session_start();
session_destroy();

// Redirect ke halaman login
header("Location: index.php");
exit;
?>
