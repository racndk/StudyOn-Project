<?php

include("dashboard-app.php");
include("koneksi.php");
?>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
    body{
        background-color: rgb(230, 230, 230);
    }
    .daftar-user{
    width: auto;
    margin-left:220px;
    padding: 100px 20px 0px 50px;
    }
    tr > td > img{
        width: 80px;
        height: 80px;
    }
    tr > td > a{
        text-decoration: none;
        color: #fff;
    }
    tr > td, tr > th{
        padding: 5px 25px;
        text-align: justify;
        align-items: center;
    }
    table {
    border-collapse: collapse;
    }
    th, td {
    border: 2px solid black;
    }
    th{
        color:#fff;
        background-color: rgba(29, 28, 61); 
    }
    .daftar-user > .add-new-user > a{
    color:#fff; 
    text-decoration:none;
    background-color: rgba(29, 28, 61); 
    padding:5px 10px;
    border-radius:5px;
    transition:.5s;
    }
    .daftar-user > .add-new-user > a:hover{
    color:#fff; 
    background-color: rgba(40, 38, 95, 0.89); 
    text-decoration:none;
    padding:5px 10px;
    border-radius:10px;
    transition:.5s;
    }
    .make-sure-container{
    background-color: rgba(29, 28, 61,0.59);
    width:100%;
    height:100vh;
    position: absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    display:none;
    }
    .make-sure-content{
    position: absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    background-color: #fff;
    color:rgba(29, 28, 61);
    padding: 30px 30px;
    }
    .confirm-button{
        display:flex;
        justify-content:center;
        margin-top:30px;
    }
    .confirm-button > a{
        text-decoration:none;
        color:#fff;
        margin:0px 10px;
        padding: 10px 30px;
        background-color: rgba(29, 28, 61);
        transition:.5s;
        border-radius:5px;
        cursor:pointer;
    }
    .confirm-button > .save:hover{
        background-color: red;
        transition:.5s;
        border-radius:10px;
    }
    .confirm-button > .cancel:hover{
        background-color: green;
        transition:.5s;
        border-radius:10px;
    }
    .link-dark{color:rgba(29, 28, 61)!important;transition:.5s;}
    .link-dark:focus,
    .link-dark:hover{color:rgba(29, 28, 61, 0.455)!important;transition:.5s;}
</style>
<div class="daftar-user">
    <div class="add-new-user" style="margin:10px 0; ">
        <a href="tambah-user.php">Tambah Guru</a>
    </div>
    <table>
        <tr>
            <th>Id</th>
            <th>Foto</th>
            <th>Nama</th>
            <th>Role</th>
            <th>Kelas</th>
            <th>Username</th>
            <th>Password</th>
            <th>Detail</th>
            <th>Update</th>
            <th>Delete  </th>
        </tr>
        <?php
        $no = 1;
        $get_data = mysqli_query($conn,"select * from user where role = 'Guru'");
        while ($show = mysqli_fetch_array($get_data)) {
            echo "
            <tr>
                <td>$no</td>
                <td>";
                
            if ($show['profile'] == NULL) {
                echo '<img width="50px" height="50px" src="Asset/default-profile-dark.png" alt="Default Profile"">';
            } else {
                echo '<img style = "border-radius:50%; width="50px" height="50px" src="data:image/jpeg;base64,' .base64_encode($show['profile']) . '" alt="Profile" >';
            }
            
            echo '</td>
                <td>'.$show['nama'].'</td>
                <td>'.$show['role'].'</td>
                <td>'.$show['kelas'].'</td>
                <td>'.$show['username'].'</td>
                <td>'.$show['password'].'</td>
                <td><a href="detail-user.php?id='.$show['id_siswa'].'" class="link-dark" style = "cursor:pointer; display:flex; justify-content:center;">Detail</a></td>
                <td class="icon-action"><a href="edit.php?id='.$show['id_siswa'].'" class="link-dark" style = "cursor:pointer; display:flex; justify-content:center;"><i class=" fa-solid fa-pen-to-square fs-5 me-3"></i></a></td>
                <td class="icon-action"><a onclick="makeSure(\''.$show['nama'].'\')" class="link-dark" style = "cursor:pointer; display:flex; justify-content:center;"><i class="fa-solid fa-trash fs-5"></i></a></td>
            </tr>
            
            <div class="make-sure-container" id="make-sure">
            <div class="make-sure-content">
                <h3 id="delete-message"></h3>
                <div class="confirm-button">
                    <a href="delete.php?id='.$show['id_siswa'].'" class="save">Ya</a>
                    <a onclick="closePopUp()" class="cancel">Tidak</a>
                </div>
            </div>
            </div>
            ';
            $no++;
        }

?>
    </table>
</div>
<!-- JavaScript Pop Up -->
<script>
    function makeSure(nama){
        var element = document.getElementById("make-sure");
        var deleteMessage = document.getElementById("delete-message");
        deleteMessage.textContent = "Yakin ingin menghapus "+nama+"?";
        element.style.display = 'block';
    }
    function closePopUp(){
        var element = document.getElementById("make-sure");
        element.style.display = 'none'
    }
</script>
<!-- Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<?php
include("footer.php");
?>