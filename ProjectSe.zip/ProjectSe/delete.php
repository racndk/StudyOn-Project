<?php
include("koneksi.php");

// Cek apakah parameter id_siswa ada dalam URL
if (isset($_GET['id'])) {
    $id_siswa = $_GET['id'];

    // Lakukan operasi penghapusan data sesuai dengan id_siswa
    $query = "DELETE FROM user WHERE id_siswa = '$id_siswa'";
    $result = mysqli_query($conn, $query);

    // Cek apakah penghapusan berhasil
    if ($result) {
        header("Location: data-siswa.php");
    } else {
        echo "Gagal menghapus data.";
    }
} else {
    echo "Parameter id_siswa tidak ditemukan.";
}

mysqli_close($conn);
?>
