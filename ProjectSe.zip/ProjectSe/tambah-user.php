<?php
include("dashboard-app.php");
include("koneksi.php");
if (isset($_POST['submit'])) {
    // Ambil nilai dari form
    $idSiswa = isset($_POST['id_siswa']) ? $_POST['id_siswa'] : '';
    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';
    $kelas = isset($_POST['kelas']) ? $_POST['kelas'] : '';
    $usia = isset($_POST['usia']) ? $_POST['usia'] : '';
    $noTelepon = isset($_POST['no_telp']) ? $_POST['no_telp'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
    $jenisKelamin = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : '';

    // Mengunggah foto pengguna ke dalam kolom "profile"
    if (isset($_FILES['foto']) && $_FILES['foto']['size'] > 0) {
        $foto = $_FILES['foto']['tmp_name'];
        $fotoContent = file_get_contents($foto);
    } else {
        $fotoContent = null; // Set to null if no file is uploaded
    }

    // Memasukkan data ke dalam tabel user
    $query = "INSERT INTO user (id_siswa, nama, role, kelas, usia, no_telp, username, password, alamat, jenis_kelamin, profile)
            VALUES ('$idSiswa', '$nama', '$role', '$kelas', '$usia', '$noTelepon', '$username', '$password', '$alamat', '$jenisKelamin', ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $fotoContent);
    $result = $stmt->execute();

    if ($result) {
        exit();
    } else {
        // Jika insert gagal, tampilkan pesan error
        echo "Error: " . $conn->error;
    }
}

?>
<style>
    body{
        background-color: rgb(230, 230, 230);
    }
</style>
<link rel="stylesheet" href="CSS/tambah-user.css">
<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<div class="title">
    <h2>Tambah Pengguna Baru</h2>
    <h4>Silahkan isi data di bawah ini</h4>
</div>
<div class="container-add-user">
    <div class="form-add-user">
        <div class="input">
            <div class="input-profile">
                <img id="profile-img" src="Asset/default-profile.png" alt="">
                <div class="btn-ganti-foto">
                    <label for="foto">Ganti Foto</label>
                </div>
            </div>
            <div class="input-data">
                <form method="POST" enctype="multipart/form-data">
                    <div class="input-data">
                        <input type="text" name="id_siswa" placeholder="Id Siswa">
                        <input type="text" name="nama" placeholder="Nama">
                    </div>
                    <div class="input-data">
                        <input type="text" name="role" placeholder="Role">
                        <input type="text" name="kelas" placeholder="Kelas">
                    </div>
                    <div class="input-data">
                        <input type="text" name="usia" placeholder="Usia">
                        <input type="text" name="no_telp" placeholder="No Telepon">
                    </div>
                    <div class="input-data">
                        <input type="text" name="username" placeholder="Username">
                        <input type="text" name="password" placeholder="Password">
                    </div>
                    <div class="input-alamat">
                        <textarea name="alamat" cols="42" rows="5" placeholder="Alamat"></textarea>
                    </div>
                    <div class="gender">
                        <label>Jenis Kelamin:</label>
                        &nbsp;
                        <input type="radio" class="form-check-input" name="jenis_kelamin" id="male" value="Laki Laki">
                        <label for="male" class="form-input-label">Laki Laki</label>
                        &nbsp;
                        <input type="radio" class="form-check-input" name="jenis_kelamin" id="female" value="Perempuan">
                        <label for="female" class="form-input-label">Perempuan</label>
                    </div>
                    <div class="btn-sub-cancel">
                        <button type="submit" class="btn btn-success" name="submit">Save</button>
                        <a href="data_user.php" class="btn btn-danger">Cancel</a>
                    </div>
                    <input type="file" name="foto" id="foto" accept="image/*" style="display:none">
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script>
    document.querySelector('.btn-ganti-foto').addEventListener('click', function() {
        document.querySelector('#foto').click();
    });

    document.querySelector('#foto').addEventListener('change', function() {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.querySelector('#profile-img').setAttribute('src', e.target.result);
        }
        reader.readAsDataURL(this.files[0]);
    });
</script>
<?php
include("footer.php");
?>