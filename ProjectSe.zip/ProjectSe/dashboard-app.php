<?php
// Memeriksa apakah pengguna sudah login, jika belum, redirect ke halaman login
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}
// Memeriksa role pengguna setelah login
if ($_SESSION['role'] == 'Murid') {
    header("Location: materi.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="CSS/dashboard-app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .menu-title > h2{
            color: #fff;
            margin: 50px 0px 50px 25px;
            font-size:20px;
        }
        .profile-button-nav{
            display: flex;
            justify-content: end;
            align-items:center;
        }
        .container-profile-button-nav{
            position: absolute;
            right:10px;
        }
        .hide{
            display:none;
        }
        .profile-button-nav{
            background-color: #fff;
        }
        .profile-button-nav > a{
            margin: 10px 20px 10px 20px;
        }
        .menu{
            width: 200px;
            background-color: rgb(29, 28, 61);
            margin: 0px 0px 20px 20px;
            border-radius:10px;
        }
        .menu > a > li{
            color: #fff;
            padding:10px;
        }
        .menu-link{
            cursor:pointer;
        }
    .logout-container{
    background-color: rgba(29, 28, 61,0.59);
    width:100%;
    height:100vh;
    position: absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    }
    .logout-content{
    position: absolute;
    top:50%;
    left:50%;
    transform:translate(-50%,-50%);
    background-color: #fff;
    color:rgba(29, 28, 61);
    padding: 30px 30px;
    }
    .logout-content > h3{
        display:flex;
        justify-content:center;
        align-items:center;
    }
    .confirm-button{
        display:flex;
        justify-content:center;
        margin-top:30px;
    }
    .confirm-button > a{
        text-decoration:none;
        color:#fff;
        margin:0px 10px;
        padding: 10px 30px;
        background-color: rgba(29, 28, 61);
        transition:.5s;
        border-radius:5px;
        cursor:pointer;
    }
    .close-pop-btn{
        display:flex;
        justify-content:flex-end;
        font-size:30px;
        cursor:pointer;
    }
    </style>
</head>
<body>
    <header>
        <div class="navigation">
            <div class="menu-title">
                <h2>Dashboard</h2>
            </div>
            <div class="menu-list">
                <ul>
                    <a href="dashboard-home.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="home-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Beranda</span>
                    </li>
                    </a>
                    <a href="data-siswa.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="file-tray-stacked-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Data Siswa</span>
                    </li>
                    </a>
                    <a href="dashboard-materi.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="newspaper-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Materi</span>
                    </li>
                    </a>
                    <a href="dashboard-tugas.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="reader-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Tugas</span>
                    </li>
                    </a>
                    <a href="dashboard-quizz.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="game-controller-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Quiz</span>
                    </li>
                    </a>
                    <a href="dashboard-nilai.php" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="medal-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Nilai</span>
                    </li>
                    </a>
                    <a onclick="openLogout()" class="menu-link">
                    <li style="display:flex; align-items: center;">
                        <ion-icon name="exit-outline" style="font-size: 20px;"></ion-icon>
                        <span style="margin-left: 5px; align-items: center;font-size: 20px;">Keluar</span>
                    </li>
                    </a>
                </ul>
            </div>
        </div>
    </header>
    <div class="profile-button-nav">
        <h4><?php echo $_SESSION['nama']?> | <?php echo $_SESSION['role']?></h4>
        <a onclick="toggleProf()">
                <?php 
                if ($_SESSION['profile'] == NULL){
                        echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="Asset/default-profile.png" alt="Default Profile">';
                }else{
                        echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="data:image/jpeg;base64,'. $_SESSION['profile'] .'" alt="Profile">';
                }
                ?>
        </a>
    </div>
    <div class="container-profile-button-nav hide" id="profile">
            <div class="menu">
                    <a>
                        <li style="display:flex; align-items: center;">
                            <?php 
                            if ($_SESSION['profile'] == NULL){
                                    echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%; margin-right:10px;" src="Asset/default-profile.png" alt="Default Profile">';
                            }else{
                                    echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%; margin-right:10px;" src="data:image/jpeg;base64,'. $_SESSION['profile'] .'" alt="Profile">';
                            }
                            ?>
                            <p><?php echo $_SESSION['nama'];?></p>
                        </li>
                    </a>
                    <a href="data-guru.php" class="menu-link">
                        <li style="display:flex; align-items: center;">
                            <ion-icon name="person-circle-outline" style="font-size: 25px;"></ion-icon>
                            <span style="margin-left: 5px; align-items: center;font-size: 20px;">Edit Profile</span>
                        </li>
                    </a>
                    <a href="dashboard-home.php" class="menu-link">
                        <li style="display:flex; align-items: center;">
                            <ion-icon name="help-circle-outline" style="font-size: 25px;"></ion-icon>
                            <span style="margin-left: 5px; align-items: center;font-size: 20px;">Bantuan</span>
                        </li>
                    </a>
                    <a onclick="openLogout()" class="menu-link">
                        <li style="display:flex; align-items: center;">
                            <ion-icon name="exit-outline" style="font-size: 25px;"></ion-icon>
                            <span style="margin-left: 5px; align-items: center;font-size: 20px;">Keluar</span>
                        </li>
                    </a>
            </div>
    </div>
    <div class="logout-container hide" id="logout">
    <div class="logout-content">
        <div class="close-pop-btn">
        <a onclick="closeLogout()"><ion-icon name="close-circle-outline"></ion-icon></a>
        </div>
        <h3>Anda mau kemana ?</h3>
        <div class="confirm-button">
            <a href="materi.php">Halaman Siswa</a>
            <a href="logout.php">Keluar Sistem</a>
        </div>
    </div>
    </div>
    <!-- ====== ionicons ======= -->
    <script>
        function toggleProf(){
        var element = document.getElementById("profile");
        if (element.classList.contains("hide")) {
            element.classList.remove("hide");
        } else {
            element.classList.add("hide");
        }
    }
    function openLogout(){
        var element = document.getElementById("logout");
        element.classList.remove("hide")
    }
    function closeLogout(){
        var element = document.getElementById("logout");
        element.classList.add("hide")
    }

    </script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>