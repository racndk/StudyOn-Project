<?php
include("dashboard-app.php");
include("koneksi.php");

// Inisialisasi variabel pesan error
$error = "";

// Cek apakah form telah disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $pertemuan = $_POST["pertemuan"];
    $materi = $_POST["materi"];

    // Periksa apakah file telah diunggah
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $file = $_FILES["file"]["name"];
        $file_tmp = $_FILES["file"]["tmp_name"];
        $uploadDir = "uploads/"; // Ganti dengan jalur direktori yang sesuai
        $targetFile = $uploadDir . $file;
        move_uploaded_file($file_tmp, $targetFile);

    } else {
        $file = "";
    }

    // Validasi data yang diinput (misalnya, memastikan tidak ada data yang kosong)

    // Jika tidak ada error, simpan data ke database
    if (empty($error)) {
        // Kode SQL untuk menyimpan data ke tabel tugas
        $query = "INSERT INTO tugas (pertemuan, file_tugas, materi) VALUES ('$pertemuan', '$file', '$materi')";

        // Eksekusi query
        if (mysqli_query($conn, $query)) {
            // Kembali ke halaman sebelumnya
            echo '<p style="position:absolute; top:50%; left:40%;">Berhasil menambahkan tugas. Silakan cek menu tugas</p>';
            exit();
        } else {
            echo 'Terjadi kesalahan dalam menyimpan data. Silakan coba lagi.';
        }
    }
}
?>

<style>
    body{
        background-color: rgb(230, 230, 230);
    }
    /* CSS styling untuk form */
    .form-container {
        margin: 50px auto;
        width: 400px;
        padding: 20px;
        background-color: #f1f1f1;
        border-radius: 5px;
    }

    .form-container h2 {
        text-align: center;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .form-group input[type="text"] {
        width: 100%;
        padding: 8px;
        border-radius: 3px;
        border: 1px solid #ccc;
    }

    .form-group input[type="file"] {
        margin-top: 5px;
    }

    .form-group .error {
        color: red;
        margin-top: 5px;
    }

    .form-group button {
        width: 100%;
        padding: 10px;
        background-color: #4CAF50;
        border: none;
        color: #fff;
        cursor: pointer;
    }
</style>

<div class="form-container">
    <h2>Tambah Tugas</h2>
    <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>" enctype="multipart/form-data">
        <div class="form-group">
            <label for="pertemuan">Pertemuan:</label>
            <input type="text" name="pertemuan" id="pertemuan" required>
        </div>
        <div class="form-group">
            <label for="materi">Materi:</label>
            <input type="text" name="materi" id="materi" required>
        </div>
        <div class="form-group">
            <label for="file">Unggah File:</label>
            <input type="file" name="file" id="file">
        </div>
        <div class="form-group">
            <button type="submit">Simpan</button>
        </div>
        <?php if (!empty($error)) { ?>
            <div class="form-group error">
                <?php echo $error; ?>
            </div>
        <?php } ?>
    </form>
</div>

<?php
include("footer.php");
?>
