<?php
// Inisialisasi session
session_start();

// Cek apakah pengguna sudah login, jika ya, redirect ke halaman welcome
if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
    exit;
}

// Cek apakah ada data yang dikirimkan melalui form login
if (isset($_POST['username']) && isset($_POST['password'])) {
    // Simpan data input username dan password
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Panggil koneksi.php untuk melakukan koneksi ke database
    require_once 'koneksi.php';

    // Query untuk memeriksa keberadaan pengguna di database
    $query = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($query);

    // Jika data pengguna ditemukan
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Simpan data pengguna ke session
        $_SESSION['username'] = $row['username'];
        $_SESSION['nama'] = $row['nama'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['profile'] = base64_encode($row['profile']);

        // Redirect ke halaman welcome
        header("Location: materi.php");
        exit;
    } else {
        // Jika data pengguna tidak ditemukan
        echo "Username atau password salah.";
    }

    // Tutup koneksi database
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyON</title>
    <link rel="stylesheet" href="CSS/login.css">
</head>
<body id="particles-js">
    <div class="navbar-container">
        <div class="navbar">
            <div class="logo">
                <a href="#">StudyON</a>
            </div>
        </div>
    </div>
    <div class="form-container">
        <form class="form" method="post" action="">
            <h4>Masuk</h4>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" value="login"><a>Masuk</a></button>
        </form>
    </div>
    <script type="text/javascript" src="JavaScript/particles.js"></script>
    <script type="text/javascript" src="JavaScript/app.js"></script>
</body>
</html>
