<?php
include("koneksi.php");
include("dashboard-app.php");
echo '<link rel="stylesheet" href="CSS/detail-user.css">';
// Memeriksa apakah parameter ID ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Mendapatkan data pengguna berdasarkan ID
    $query = "SELECT * FROM user WHERE id_siswa = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Memeriksa apakah ada data yang ditemukan
    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        ?>
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style>
    body{
        background-color: rgb(230, 230, 230);
    }
            th, td {
                border-width: 3px;
                border-color: rgba(29, 28, 61);
                border-style: solid;
            }
            .daftar-user > .add-new-user > a{
            color:#fff; 
            background-color: rgba(29, 28, 61); 
            text-decoration:none;
            padding:5px 10px;
            border-radius:5px;
            transition:.5s;
            }
            .daftar-user > .add-new-user > a:hover{
            color:#fff; 
            background-color: rgba(40, 38, 95, 0.89); 
            text-decoration:none;
            padding:5px 10px;
            border-radius:10px;
            transition:.5s;
            }
            .link-dark{color:rgba(29, 28, 61)!important;transition:.5s;}
            .link-dark:focus,
            .link-dark:hover{color:rgba(29, 28, 61, 0.455)!important; width:40px;transition:.5s;}
        </style>
        <div class="daftar-user">
            <div class="add-new-user" style="margin:10px 0; ">
                <a href="data-siswa.php">Kembali</a>
            </div>
            <table border = "3" style="border-color: rgba(29, 28, 61);">
                <tr>
                    <th>Id</th>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Role</th>
                    <th>Kelas</th>
                    <th>Usia</th>
                    <th>No. Telepon</th>
                    <th>Alamat</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Edit</th>
                </tr>
                <tr>
                    <td><?php echo $user['id_siswa']; ?></td>
                    <td>
                        <?php
                        if (isset($user['profile'])) {
                            echo '<img width="50px" height="50px" src="data:image/jpeg;base64,' . base64_encode($user['profile']) . '" alt="Profile">';
                        } else {
                            echo '<img width="50px" height="50px" src="Asset/default-profile-dark.png" alt="Default Profile">';
                        }
                        ?>
                    </td>
                    <td><?php echo $user['nama']; ?></td>
                    <td><?php echo $user['jenis_kelamin']; ?></td>
                    <td><?php echo $user['role']; ?></td>
                    <td><?php echo $user['kelas']; ?></td>
                    <td><?php echo $user['usia']; ?></td>
                    <td><?php echo $user['no_telp']; ?></td>
                    <td><?php echo $user['alamat']; ?></td>
                    <td><?php echo $user['username']; ?></td>
                    <td><?php echo $user['password']; ?></td>
                    <td class="icon-action"><a href="edit.php?id='.$show['id_siswa'].'" class="link-dark"><i class=" fa-solid fa-pen-to-square fs-5 me-3"></i></a></td>
                </tr>
            </table>
        </div>
    <?php
    } else {
        // Jika tidak ada data yang ditemukan, tampilkan pesan error
        echo "Error: Data not found.";
    }
} else {
    // Jika parameter ID tidak ada dalam URL, tampilkan pesan error
    echo "Error: Invalid ID.";
}
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<?php
include("footer.php");
?>
