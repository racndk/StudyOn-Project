<?php
// Memeriksa apakah pengguna sudah login, jika belum, redirect ke halaman login
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyON</title>
    <link rel="stylesheet" href="CSS/nav.css">
    <script>
        function toggleMenu() {
            const menuList = document.querySelector('.menu-list');
            menuList.classList.add("slide-in-toggle")
            menuList.style.position = 'absolute'
            menuList.style.display = menuList.style.display === 'block' ? 'none' : 'block';
        }
        function hideToggle(){
            const menuList = document.querySelector('.menu-list');
            menuList.style.display = 'none'
            menuList.classList.remove("slide-in-toggle")
        }
        function openProf(){
            var element = document.getElementById("profile");
            element.style.display = 'block'
        }
        function closeProf(){
            var element = document.getElementById("profile")
            element.style.display = 'none'
        }
        function openFunc(){
            var element = document.getElementById("open-schedule");
            element.classList.remove("hide","animasi-close")
            element.classList.add("slide-in")

        }
        function hideFunc(){
            var element = document.getElementById("open-schedule");
            element.classList.add("animasi-close","hide")
            element.classList.remove("slide-in")
        }
    </script>
    <script src="https://kit.fontawesome.com/6157bd9d80.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="navbar-container">
        <div class="navbar">
            <div class="logo">
                <a href="#">StudyON</a>
            </div>
            <div class="menu">
                <a href="materi.php"><img src="Asset/materi.png" alt="">Materi</a>
            </div>
            <!-- <div class="menu">
                <a href="#"><img src="Asset/jadwal.png" alt="">Jadwal</a>
            </div> -->
            <div class="menu">
                <a href="tugas.php"><img src="Asset/tugas.png" alt="">Tugas</a>
            </div>
            <div class="menu">
                <a href="#"><img src="Asset/nilai.png" alt="">Nilai</a>
            </div>
            <?php
                    if($_SESSION['role'] === 'Guru'){
                        echo '<div class="menu"><a href="dashboard-home.php"><img src="Asset/dashboard.png" alt=""><span>Dashboard</span></a></div>';
                    }
                ?>
            <div class="profile-button">
                 <a onclick="openProf()">
                    <?php 
                        if ($_SESSION['profile'] == NULL){
                            echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="Asset/default-profile.png" alt="Default Profile">';
                        }else{
                            echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="data:image/jpeg;base64,'. $_SESSION['profile'] .'" alt="Profile">';
                        }
                    ?>
                </a>
            </div>
            <div class="menu-toggle">
                <button onclick="toggleMenu()">&#9776;</button>
              </div>
              <div class="menu-list">
                <div class="menu-content">
                    <div class="close-toggle">
                        <a onclick="hideToggle()"><i class="fa-solid fa-xmark fa-2xl"></i></a>
                    </div>
                    <div class="toggle-logo-profile">
                        <a onclick="openProf()">
                            <?php 
                                if ($_SESSION['profile'] == NULL){
                                    echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="Asset/default-profile.png" alt="Default Profile">';
                                }else{
                                    echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="data:image/jpeg;base64,'. $_SESSION['profile'] .'" alt="Profile">';
                                }
                            ?>
                        </a>
                    </div>
                <a href="materi.php"><img src="Asset/materi.png" alt=""><span>Materi</span></a>
                <!-- <a onclick="openFunc()"><img src="Asset/jadwal.png" alt=""><span>Jadwal</span></a> -->
                <a href="tugas.php"><img src="Asset/tugas.png" alt=""><span>Tugas</span></a>
                <a href="#"><img src="Asset/nilai.png" alt=""><span>Nilai</span></a>
                <?php
                    if($_SESSION['role'] === 'Guru'){
                        echo '<a href="dashboard-home.php"><img src="Asset/dashboard.png" alt=""><span>Dashboard</span></a>';
                    }
                ?>
                </div>
              </div>
        </div>
    </header>
    <div class="profile-container" id="profile">
        <div class="close-prof">
            <a onclick="closeProf()"><i class="fa-solid fa-xmark" style = "color:#fff; cursor: pointer;"></i></a>
        </div>
        <div class="profile-title">
            <div class="profile-button">
                 <a onclick="openProf()">
                    <?php 
                        if ($_SESSION['profile'] == NULL){
                            echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="Asset/default-profile.png" alt="Default Profile">';
                        }else{
                            echo '<img width="50px" height="50px" style = "cursor:pointer; border-radius:50%;" src="data:image/jpeg;base64,'. $_SESSION['profile'] .'" alt="Profile">';
                        }
                    ?>
                </a>
            </div>
            <h4><?php echo $_SESSION['nama']; ?> |  <span> &nbsp;<?php echo $_SESSION['role']; ?></span> </h4>
        </div>
        <div class="profile-menu">
            <a href="profile.html">
                <img src="Asset/default-profile.png" alt=""><span>
                Ubah Profile</span>
            </a>
            <a href="profile.html"><img src="Asset/next-btn.png" alt="" style="width: 15px; height:15px;"></a>
        </div>
        <div class="profile-menu">
            <a href="logout.php">
                <img src="Asset/exit-btn.png" alt=""><span>
                Keluar</span>
            </a>
            <a href="logout.php"><img src="Asset/next-btn.png" alt="" style="width: 15px; height:15px;"></a>
        </div>
    </div>
    <div class="frame-jadwal hide" id="open-schedule">
        <div class="container-jadwal">
            <div class="wrapper close" >
                <div class="icon facebook">
                <a onclick="hideFunc()"><span><i class="fa-solid fa-xmark"></i></span></a>
                </div>
            </div>
            <div>
                <iframe src="jadwal.html" frameborder="0"></iframe>
            </div>
        </div>
    </div>
    
    <div class="frame-jadwal hide" id="open-schedule">
        <div class="container-jadwal">
            <div class="wrapper close" >
                <div class="icon facebook">
                <a onclick="hideFunc()"><span><i class="fa-solid fa-xmark"></i></span></a>
                </div>
            </div>
            <div>
                <iframe src="jadwal.html" frameborder="0"></iframe>
            </div>
        </div>
    </div>
        <!-- <li><a href="materi.php?id=1">Materi 1</a></li>
        <li><a href="materi.php?id=2">Materi 2</a></li>
        <li><a href="materi.php?id=3">Materi 3</a></li> -->