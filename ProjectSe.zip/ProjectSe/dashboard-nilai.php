<?php
include("dashboard-app.php");
include("koneksi.php");
?>
<style>
    body{
        background-color: rgb(230, 230, 230);
    }
    </style>
<link rel="stylesheet" href="CSS/tambah-user.css">
<div class="title">
    <h2>Score On Progress....</h2>
</div>
<?php
include("footer.php");
?>